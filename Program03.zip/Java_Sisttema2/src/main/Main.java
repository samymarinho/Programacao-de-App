package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.Produto;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner (System.in);
		ArrayList<Produto> Produtos = new ArrayList();
		boolean val = true;
		int opcao;
		while(val) {
			System.out.println("Bem vindo ao nosso sistema!");
			System.out.println("O que deseja fazer hoje?");
			System.out.println("[1] Cadastrar um novo produto");
			System.out.println("[2] Ver lista de produtos cadastrados");
			System.out.println("[3] Retirar um produto cadastrado do estoque");
			System.out.println("[4] Excluir um produto cadastrado");
			System.out.println("[5] Sair do sistema");
			opcao = scan.nextInt();
			String aux;
			switch (opcao) {
			case 1:
				Produto produto = new Produto();
				System.out.println("Insira as informações abaixo");
				System.out.println("Nome" );
				aux = scan.next();
				produto.setNome(aux);
				System.out.println("Preço: ");
				aux = scan.next();
				produto.setPreco(Double.parseDouble(aux));
				System.out.println("Estoque: ");
				aux = scan.next();
				produto.setEstoque(Integer.parseInt(aux));
				
				Produtos.add(produto);
				System.out.println("Produto cadastrado.");
				break;
				
			case 2:
			System.out.println("Produtos cadastrados");
			for (int i = 0; i < Produtos.size(); i++) {
				Produto produto1 = new Produto();
				produto1 = Produtos.get(i);
				System.out.println(i + "-" + produto1.getNome()+ " " + produto1.getEstoque());
			}
			break;
		case 3:
		int indice;
		String escolha;
		System.out.println("Digite o índice de qual pessoa deseja editar o estoque");
		
		for (int i = 0; i < Produtos.size(); i++) {
			Produto produto1 = new Produto();
			produto1 = Produtos.get(i);
			System.out.println(i + "-" + produto1.getNome());
			
		}
		int quantidade;
		indice = scan.nextInt();
		Produto produto3 = new Produto();
		produto3 = Produtos.get(indice);
		System.out.println("O produto " + produto3.getNome()+ " tem "+ produto3.getEstoque()+" unidades");
		System.out.println("Informe quantas unidades quer retirar:");
		quantidade = scan.nextInt();
		produto3.setEstoque(produto3.getEstoque() - quantidade);
		Produtos.set(indice, produto3);
		System.out.println("Produto foi editado! ");
		break;
		
		case 4: 
			int indice4;
			String escolha4;
			System.out.println("Digite o índice de qual pessoa deseja excluir");
			
			for (int i = 0; i < Produtos.size(); i++) {
				Produto produto4 = new Produto();
				produto4 = Produtos.get(i);
				System.out.println(i + "-" + produto4.getNome());
			}
			System.out.println();
			indice4 = scan.nextInt();
			Produto produto4 = new Produto();
			produto4 = Produtos.get(indice4);
			System.out.println("Tem certeza que deseja excluir o"+ produto4.getNome()+ "? (sim ou não)");
			escolha4 = scan.next();
			if (escolha4.equals("sim")) {
				Produtos.remove(indice4);
				System.out.println("O produto foi excluído");
			} else {
				System.out.println("O produto não foi excluído ");
			}
			break;
		case 5:
			System.out.println("Você saiu do sistema! ");
			val = false;
		default: 
			System.out.println("Escolha uma opção válida!");
			break;
		}
	}
}

}

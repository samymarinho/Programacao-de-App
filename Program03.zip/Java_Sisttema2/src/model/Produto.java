package model;

public class Produto {
private String nome;
private double preco;
private int estoque;
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public double getPreco() {
	return preco;
}
public void setPreco(double aux) {
	this.preco = aux;
}
public int getEstoque() {
	return estoque;
}
public void setEstoque(int aux) {
	this.estoque = aux;
}
public Produto(String nome, double preco, int estoque) {
	super();
	this.nome = nome;
	this.preco = preco;
	this.estoque = estoque;
}
public Produto() {
	super();
}

}
